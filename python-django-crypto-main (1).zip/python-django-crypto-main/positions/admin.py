from django.contrib import admin
from .models import Test, Position

# Register your models here.

admin.site.register(Test)
admin.site.register(Position)